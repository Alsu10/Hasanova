/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tretiisemestr;
import java.awt.event.ActionEvent; 
import java.awt.event.ActionListener; 
import java.io.BufferedReader; 
import java.io.FileReader; 
import java.io.IOException; 
import java.io.LineNumberReader; 
import javax.swing.JFrame; 
import javax.swing.JTextArea; 
/**
 *
 * @author LENOVO
 */
public class Class implements ActionListener { 
FileReaderClass myIzfile1 = new FileReaderClass(); 
JTextArea textArea; 

public Class(String text, int x, int y) { 
JFrame frm = new JFrame("Справка"); 
frm.setBounds(x, y, 450, 300); 
frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
frm.setLayout(null); 
textArea = new JTextArea(); 
textArea.setBounds(50, 50, 330, 250); 
textArea.setEditable(false); 
textArea.append(myIzfile1.read()); 
frm.add(textArea); 
frm.setVisible(true); 
} 

public void actionPerformed(ActionEvent ae) { 

} 
} 
class FileReaderClass { 

public String read() { 
StringBuilder sb = new StringBuilder(); 
try { 
String s; 
FileReader fr = new FileReader("C:\\alsu\\dada.txt"); 
BufferedReader br = new BufferedReader(fr); 
LineNumberReader lr = new LineNumberReader(br); 
while ((s = lr.readLine()) != null) { 
sb.append(s); 
sb.append("\n"); 
} 
} catch (IOException e) { 
System.out.println(e.getMessage()); 
} 
return sb.toString(); 
} 
    
}
