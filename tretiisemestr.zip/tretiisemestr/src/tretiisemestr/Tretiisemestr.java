/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tretiisemestr;
import java.awt.event.ActionEvent; 
import java.awt.event.ActionListener; 
import javax.swing.JButton; 
import javax.swing.JFrame; 
import javax.swing.JLabel; 
import javax.swing.JOptionPane; 
import javax.swing.SwingUtilities; 

/**
 *
 * @author LENOVO
 */
public class Tretiisemestr implements ActionListener { 

public Tretiisemestr() { 
initComponents(); 
} 

private JFrame viewForm; 

private void initComponents() { 
viewForm = new JFrame("Окно заставки и справки"); 
viewForm.setSize(400, 400); 
viewForm.setVisible(true); 
viewForm.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE); 

JButton but = new JButton("Начать работу"); 
but.setVisible(true); 
but.setLocation(95, 65); 
but.setSize(165, 50); 
JButton button = new JButton("Подробнее"); 
button.setVisible(true); 
button.setLocation(95, 125); 
button.setSize(165, 50); 
button.addActionListener(new ActionListener() { 

//FileReader fr = new FileReader("D:/workspace/Test/1.txt"); 
//BufferedReader br = new BufferedReader(fr); 
//LineNumberReader lr = new LineNumberReader(br); 
//while ((s = lr.readLine()) != null) { 
//sb.append(s); 
//sb.append("\n"); 
//} 

public void actionPerformed(ActionEvent e) { 
// JOptionPane.showMessageDialog(viewForm, "Приветики", 
// "Справка", JOptionPane.WARNING_MESSAGE); 
// 
// } 
//class Izfile { 
//public static void main(String[] args) { 
new Class("Текст", 300, 400); 

    /**
     * @param args the command line arguments
     */
} 

}); 
viewForm.getContentPane().add(button); 
viewForm.getContentPane().add(new JLabel()); 
viewForm.getContentPane().add(but); 
viewForm.getContentPane().add(new JLabel()); 
} 

public void actionPerformed(ActionEvent action) { 
} 

public static void main(String[] args) { 
SwingUtilities.invokeLater(new Runnable() { 
public void run() { 
new Tretiisemestr(); 
} 
}); 
} 
}
